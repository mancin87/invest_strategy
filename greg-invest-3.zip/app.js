import * as Utils from './modules/utils.js';

// Глобальный реестр (сюда модули будут сообщать свои функции запуска)
window.ModuleRegistry = {};

document.addEventListener('DOMContentLoaded', async () => {
    
    // 1. Инициализация темы (светлая/темная)
    Utils.initTheme();

    // 2. Динамическая загрузка модулей
    for (const plugin of CONFIG.plugins) {
        if (!plugin.enabled) {
            hideTab(plugin.id);
            continue;
        }

        try {
            // Пытаемся загрузить файл
            const module = await import(plugin.path);
            
            // Если загрузился, запускаем его init
            if (module.init) {
                // Передаем модулю функцию регистрации "registerFn"
                module.init((mainActionFunction) => {
                    if (mainActionFunction) {
                        window.ModuleRegistry[plugin.id] = mainActionFunction;
                    }
                });
            }

        } catch (error) {
            console.error(`🔴 ОШИБКА в модуле [${plugin.id}]:`, error);
            console.warn(`Модуль "${plugin.id}" отключен, чтобы сайт продолжил работать.`);
            hideTab(plugin.id); // Скрываем вкладку сломанного модуля
        }
    }

    // 3. Настройка переключения вкладок
    setupTabs();

    // 4. Обработчик кнопки Calculate и Enter
    const triggerCalculation = (e) => {
        if (e.type === 'keydown' && e.key !== 'Enter') return;
        
        // Находим активную вкладку
        const activeView = document.querySelector('.tab-content.active');
        if (!activeView) return;

        // Если нажали Enter в поле ввода, предотвращаем перезагрузку формы
        if (e.type === 'keydown') {
            // Исключение: не блокируем Enter в textarea, если они будут
            if(e.target.tagName !== 'TEXTAREA') e.preventDefault();
        }

        // Получаем ID модуля (view-simulation -> simulation)
        const moduleId = activeView.id.replace('view-', '');
        
        // Запускаем функцию из реестра
        const runFunc = window.ModuleRegistry[moduleId];
        if (typeof runFunc === 'function') {
            runFunc();
            
            // Анимация кнопки
            const btn = document.getElementById('calcBtn');
            if(btn && e.type === 'keydown') {
                btn.classList.add('scale-95');
                setTimeout(() => btn.classList.remove('scale-95'), 100);
            }
        }
    };

    const calcBtn = document.getElementById('calcBtn');
    if (calcBtn) calcBtn.addEventListener('click', triggerCalculation);
    document.addEventListener('keydown', triggerCalculation);

    // Открываем вкладку по умолчанию
    switchTab(CONFIG.defaultTab);
});

// --- Вспомогательные функции ---

function hideTab(id) {
    const btn = document.querySelector(`button[data-target="${id}"]`);
    if (btn) btn.style.display = 'none';
    
    // Спец. логика для пресетов (скрыть кнопку в шапке)
    if (id === 'presets') {
        const controls = document.getElementById('preset-controls');
        const btnModal = document.getElementById('btn-presets-modal');
        if(controls) controls.style.display = 'none';
        if(btnModal) btnModal.style.display = 'none';
    }
}

function setupTabs() {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(btn => {
        btn.addEventListener('click', (e) => switchTab(e.target.getAttribute('data-target')));
    });
}

function switchTab(targetId) {
    const tabs = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.tab-content');

    // Сброс стилей
    tabs.forEach(t => {
        t.classList.remove('bg-white', 'dark:bg-gray-700', 'shadow-sm', 'text-gray-900', 'dark:text-gray-100');
        t.classList.add('text-gray-500', 'hover:text-gray-700', 'dark:text-gray-400', 'dark:hover:text-gray-200');
    });
    contents.forEach(c => c.classList.remove('active'));

    // Активация новой вкладки
    const activeBtn = document.querySelector(`button[data-target="${targetId}"]`);
    const activeView = document.getElementById(`view-${targetId}`);

    if (activeBtn && activeView) {
        activeBtn.classList.add('bg-white', 'dark:bg-gray-700', 'shadow-sm', 'text-gray-900', 'dark:text-gray-100');
        activeBtn.classList.remove('text-gray-500', 'hover:text-gray-700');
        activeView.classList.add('active');
        
        // Авто-расчет при переключении (если нужно)
        const runFunc = window.ModuleRegistry[targetId];
        if (runFunc) runFunc();
    }
}