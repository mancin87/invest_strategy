// config.js
// Система плагинов. Если модуль сломан или enabled: false, он просто не загрузится.

const CONFIG = {
    plugins: [
        { id: 'projection', path: './modules/projection.js', enabled: true },
        { id: 'averaging',  path: './modules/averaging.js',  enabled: true },
        { id: 'portfolio',  path: './modules/portfolio.js',  enabled: true },
        { id: 'presets',    path: './modules/presets.js',    enabled: true },
		{ id: 'search',     path: './modules/search.js',     enabled: true }
    ],
    defaultTab: 'projection' // Какая вкладка открывается первой
};