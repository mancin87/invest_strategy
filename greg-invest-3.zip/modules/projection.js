import { fmtMoney } from './utils.js';

let chartInstance = null;

const PERSISTENT_IDS = [
    'shares', 'avgPrice', 'currPrice', 'initialCapital', 'monthlyContribution',
    'divYield', 'reinvestMode', 'duration', 'scenario', 'manualGrowth',
    'enableVolatility', 'volatilityRange'
];

export function init(registerFn) {
    if (registerFn) registerFn(runSimulation);

    loadInputs();

    PERSISTENT_IDS.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', (e) => {
                handleInput(e);
                runSimulation();
            });
            el.addEventListener('change', (e) => {
                handleInput(e);
                runSimulation();
            });
        }
    });

    // Очистка
    const clearBtn = document.getElementById('simClearBtn');
    if(clearBtn) clearBtn.addEventListener('click', clearFields);

    // --- ЛОГИКА ЗАГРУЗКИ ИЗ ПОРТФЕЛЯ ---
    loadPortfolioTickers(); // <--- ВАЖНО: Запуск при старте
    
    const portSelect = document.getElementById('projPortSelect');
    if (portSelect) {
        // При клике на селект - обновляем список (вдруг портфель изменился)
        portSelect.addEventListener('focus', loadPortfolioTickers);
        
        // При выборе - заполняем поля
        portSelect.addEventListener('change', (e) => {
            if (e.target.value) loadFromPortfolio(e.target.value);
        });
    }
    // -----------------------------------

    updateGrowthInput();
    toggleVolatilityControls();
    
    runSimulation();
}

function handleInput(e) {
    const id = e.target.id;
    const val = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    localStorage.setItem(id, val);

    if (id === 'scenario') updateGrowthInput();
    if (id === 'enableVolatility' || id === 'volatilityRange') toggleVolatilityControls();
    if (id === 'volatilityRange') {
        document.getElementById('volatilityValueText').innerText = val + '%';
    }
}

function loadInputs() {
    PERSISTENT_IDS.forEach(id => {
        const savedValue = localStorage.getItem(id);
        if (savedValue !== null) {
            const el = document.getElementById(id);
            if (el) {
                if(el.type === 'checkbox') el.checked = (savedValue === 'true');
                else el.value = savedValue;
            }
        }
    });
    const range = document.getElementById('volatilityRange');
    if(range) document.getElementById('volatilityValueText').innerText = range.value + '%';
}

function loadPortfolioTickers() {
    const select = document.getElementById('projPortSelect');
    if (!select) return;
    
    const savedPort = localStorage.getItem('portfolio_data');
    if (!savedPort || JSON.parse(savedPort).length === 0) {
        select.innerHTML = '<option value="">(Portfolio empty)</option>';
        select.disabled = true;
        return;
    }
    
    const assets = JSON.parse(savedPort);
    assets.sort((a,b) => a.ticker.localeCompare(b.ticker));
    
    // Сохраняем текущий выбор если есть
    const currentVal = select.value;
    
    select.disabled = false;
    select.innerHTML = '<option value="">Select from Portfolio...</option>' + 
        assets.map(a => `<option value="${a.ticker}">${a.ticker}</option>`).join('');
        
    if(currentVal) select.value = currentVal;
}

function loadFromPortfolio(ticker) {
    const savedPort = localStorage.getItem('portfolio_data');
    if (!savedPort) return;
    const assets = JSON.parse(savedPort);
    const asset = assets.find(a => a.ticker === ticker);
    
    if (asset) {
        // Обновляем глобальный тикер
        const tickerEl = document.getElementById('tickerSymbol');
        if(tickerEl) {
            tickerEl.value = asset.ticker;
            localStorage.setItem('tickerSymbol', asset.ticker);
        }

        // Обновляем поля модуля
        document.getElementById('shares').value = asset.qty;
        document.getElementById('avgPrice').value = asset.avg;
        document.getElementById('currPrice').value = asset.curr;
        
        // Эмулируем ввод для сохранения и пересчета
        const event = new Event('input');
        ['shares', 'avgPrice', 'currPrice'].forEach(id => {
            const el = document.getElementById(id);
            if(el) {
                localStorage.setItem(id, el.value); // Принудительное сохранение
                el.dispatchEvent(event);
            }
        });
        
        // Сбрасываем селект (чтобы можно было выбрать тот же самый актив снова)
        document.getElementById('projPortSelect').value = "";
    }
}

function toggleVolatilityControls() {
    const isChecked = document.getElementById('enableVolatility').checked;
    const container = document.getElementById('volatilityContainer');
    if (isChecked) container.classList.remove('hidden');
    else container.classList.add('hidden');
}

function updateGrowthInput() {
    const scenario = document.getElementById('scenario').value;
    const growthInput = document.getElementById('manualGrowth');
    let currentVal = parseFloat(growthInput.value) || 0;

    if (scenario === 'flat') {
        growthInput.disabled = true;
        growthInput.value = 0;
    } else {
        growthInput.disabled = false;
        if (currentVal === 0) {
            if (scenario === 'bull') growthInput.value = 10;
            if (scenario === 'bear') growthInput.value = -10;
        } else {
            if (scenario === 'bull') growthInput.value = Math.abs(currentVal);
            if (scenario === 'bear') growthInput.value = -Math.abs(currentVal);
        }
    }
    localStorage.setItem('manualGrowth', growthInput.value);
}

export function runSimulation() {
    const initialShares = parseFloat(document.getElementById('shares').value) || 0;
    const avgPrice = parseFloat(document.getElementById('avgPrice').value) || 0;
    const startPrice = parseFloat(document.getElementById('currPrice').value) || 0;
    const initialCapital = parseFloat(document.getElementById('initialCapital').value) || 0;
    const monthlyContrib = parseFloat(document.getElementById('monthlyContribution').value) || 0;
    const divYieldPercent = parseFloat(document.getElementById('divYield').value) || 0;
    const reinvestMode = document.getElementById('reinvestMode').value;
    const durationMonths = parseInt(document.getElementById('duration').value);
    const enableVolatility = document.getElementById('enableVolatility').checked;
    const volatilityRangeVal = parseFloat(document.getElementById('volatilityRange').value);
    const scenario = document.getElementById('scenario').value;
    
    let annualGrowthPct = parseFloat(document.getElementById('manualGrowth').value) || 0;
    if(scenario === 'flat') annualGrowthPct = 0; 

    const chartTitle = document.getElementById('chartTitle');
    if(chartTitle) chartTitle.innerText = `Equity Projection (${durationMonths} mon.)`;

    let currentPrice = startPrice;
    let currentShares = initialShares;
    let accumulatedCash = initialCapital;
    let totalInvested = (initialShares * avgPrice) + initialCapital; 
    
    let cumulativeDividends = 0;
    let totalEquity = 0;
    let equityCurve = [];
    let investmentLine = [];
    let breakEvenMonth = null;
    
    let startEquity = (currentShares * startPrice) + accumulatedCash;
    equityCurve.push(startEquity);
    investmentLine.push(totalInvested);

    let tableHTML = '';
    
    let monthlyGrowthRate = scenario !== 'flat' ? Math.pow(1 + (annualGrowthPct / 100), 1 / 12) - 1 : 0;
    const volatility = enableVolatility ? (volatilityRangeVal / 100) : 0;

    const fmtNum = (num) => num.toFixed(2);
    const randRange = (min, max) => Math.random() * (max - min) + min;

    for (let m = 1; m <= durationMonths; m++) {
        let shock = enableVolatility ? (Math.random() - 0.5) * 2 * volatility : 0;
        currentPrice = currentPrice * (1 + monthlyGrowthRate + shock);
        if (currentPrice < 0.01) currentPrice = 0.01;

        let sharesFromDCA = 0;
        if(monthlyContrib > 0) {
            sharesFromDCA = monthlyContrib / currentPrice;
            currentShares += sharesFromDCA;
            totalInvested += monthlyContrib;
        }

        let monthlyYield = (divYieldPercent / 100) / 12;
        let divNoise = enableVolatility ? randRange(0.95, 1.05) : 1.0;
        let currentDivTotal = (currentPrice * currentShares) * monthlyYield * divNoise;
        cumulativeDividends += currentDivTotal;
        
        let actionText = "";
        let dcaLabel = sharesFromDCA > 0 ? `DCA: +${sharesFromDCA.toFixed(2)}` : "";

        if (reinvestMode === 'reinvest') {
            let sharesFromDivs = currentDivTotal / currentPrice;
            currentShares += sharesFromDivs;
            let divLabel = `Div: +${sharesFromDivs.toFixed(2)}`;
            actionText = dcaLabel ? `${dcaLabel} | ${divLabel}` : divLabel;
        } else {
            accumulatedCash += currentDivTotal;
            let divLabel = `Div: +${fmtMoney(currentDivTotal)}`;
            actionText = dcaLabel ? `${dcaLabel} | ${divLabel}` : divLabel;
        }

        let positionsValue = currentShares * currentPrice;
        totalEquity = positionsValue + accumulatedCash;
        equityCurve.push(totalEquity);
        investmentLine.push(totalInvested);

        if (totalEquity >= totalInvested && breakEvenMonth === null) breakEvenMonth = m;

        if (durationMonths <= 60 || m % Math.ceil(durationMonths/60) === 0 || m === durationMonths) {
            const rowClass = m % 2 === 0 ? 'bg-gray-50 dark:bg-gray-800/50' : '';
            const pnlColor = totalEquity >= totalInvested ? 'text-green-500' : 'text-red-500';
            
            tableHTML += `
                <tr class="${rowClass} hover:bg-gray-100 dark:hover:bg-gray-700 transition border-b dark:border-gray-800">
                    <td class="px-4 py-2 font-mono">${m}</td>
                    <td class="px-4 py-2 text-gray-600 dark:text-gray-400">$${currentPrice.toFixed(2)}</td>
                    <td class="px-4 py-2 text-green-600">+${fmtMoney(currentDivTotal)}</td>
                    <td class="px-4 py-2 text-purple-600 dark:text-purple-400 font-medium text-xs">${actionText}</td>
                    <td class="px-4 py-2 font-mono text-xs">${fmtNum(currentShares)}</td>
                    <td class="px-4 py-2 font-mono text-xs text-gray-500">${fmtMoney(accumulatedCash)}</td>
                    <td class="px-4 py-2 text-right font-bold ${pnlColor}">${fmtMoney(totalEquity)}</td>
                </tr>`;
        }
    }

    document.getElementById('tableBody').innerHTML = tableHTML;
    
    const finalPnL = totalEquity - totalInvested;
    const finalPnLColor = finalPnL >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400';
    
    document.getElementById('kpiPnL').innerHTML = `<span class="${finalPnLColor}">${fmtMoney(finalPnL)}</span>`;
    
    const roi = totalInvested > 0 ? ((finalPnL/totalInvested)*100).toFixed(2) : "0.00";
    document.getElementById('kpiPnLPercent').innerText = `${roi}% ROI`;
    
    document.getElementById('kpiTotalDivs').innerText = fmtMoney(cumulativeDividends);
    document.getElementById('kpiTotalShares').innerText = fmtNum(currentShares);
    document.getElementById('kpiTotalEquity').innerText = fmtMoney(totalEquity);
    
    const shareDiff = currentShares - initialShares;
    const diffSign = shareDiff >= 0 ? '+' : '';
    document.getElementById('kpiShareDiff').innerText = `${diffSign}${fmtNum(shareDiff)} over period`;
    
    const beEl = document.getElementById('kpiBreakeven');
    if(beEl) {
        beEl.innerText = breakEvenMonth ? `Month ${breakEvenMonth}` : "Never";
        beEl.className = breakEvenMonth ? "text-lg font-bold text-green-600 dark:text-green-400" : "text-lg font-bold text-gray-400";
    }

    renderChart(equityCurve, investmentLine, durationMonths);
}

function renderChart(equityData, investmentData, duration) {
    const ctx = document.getElementById('strategyChart');
    if(!ctx) return;
    
    if (chartInstance) chartInstance.destroy();
    
    const isDark = document.documentElement.classList.contains('dark');
    const gridColor = isDark ? '#374151' : '#e5e7eb';
    const textColor = isDark ? '#9ca3af' : '#4b5563';
    
    const labels = Array.from({length: duration + 1}, (_, i) => i === 0 ? 'Start' : `M${i}`);

    chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Total Equity',
                    data: equityData,
                    borderColor: '#10b981', 
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: duration > 60 ? 0 : 2
                },
                {
                    label: 'Invested Capital',
                    data: investmentData,
                    borderColor: '#ef4444',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    pointRadius: 0,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { labels: { color: textColor } },
                tooltip: { callbacks: { label: function(c) { let l = c.dataset.label || ''; if (l) l += ': '; if (c.parsed.y !== null) l += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(c.parsed.y); return label; } } }
            },
            scales: {
                x: { grid: { color: gridColor }, ticks: { color: textColor, maxTicksLimit: 12 } },
                y: { grid: { color: gridColor }, ticks: { color: textColor } }
            }
        }
    });
}

function clearFields() {
    const simIds = ['shares', 'avgPrice', 'currPrice', 'initialCapital', 'monthlyContribution', 'divYield', 'manualGrowth'];
    
    simIds.forEach(id => { 
        const el = document.getElementById(id); 
        if(el) { 
            el.value = ''; 
            localStorage.removeItem(id); 
        } 
    });

    const rMode = document.getElementById('reinvestMode');
    if(rMode) rMode.selectedIndex = 0;
    
    const dur = document.getElementById('duration');
    if(dur) dur.value = "12";
    
    const scen = document.getElementById('scenario');
    if(scen) scen.value = 'flat';
    
    const portSelect = document.getElementById('projPortSelect');
    if(portSelect) portSelect.value = ""; // Сброс селекта при очистке

    localStorage.removeItem('reinvestMode'); 
    localStorage.removeItem('duration'); 
    localStorage.removeItem('scenario');
    
    updateGrowthInput();
    runSimulation();
}