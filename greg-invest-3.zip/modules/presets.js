// modules/presets.js

const PERSISTENT_IDS = [
    'tickerSymbol', 
    'shares', 'avgPrice', 'currPrice', 'initialCapital', 'monthlyContribution',
    'divYield', 'reinvestMode', 'duration', 'scenario', 'manualGrowth',
    'avg_shares', 'avg_entryPrice', 'avg_marketPrice', 
    'avg_sellCount', 'avg_buyCount', 'avg_buyPrice',
    'enableVolatility', 'volatilityRange',
    'sheetUrl'
];

const PRESETS_KEY = 'strategy_presets';

export function init(registerFn) {
    // 1. Открытие/Закрытие
    const btnOpen = document.getElementById('btn-presets-modal');
    if (btnOpen) btnOpen.addEventListener('click', openPresetsModal);

    const btnClose = document.getElementById('closePresetsBtn');
    if (btnClose) btnClose.addEventListener('click', closePresetsModal);

    // 2. Поиск
    const searchInput = document.getElementById('presetSearch');
    if (searchInput) searchInput.addEventListener('input', renderPresetsList);

    // 3. Сохранение
    const btnSave = document.getElementById('savePresetBtn');
    if (btnSave) btnSave.addEventListener('click', savePreset);

    // 4. Загрузка из хедера
    const headerSelect = document.getElementById('headerPresetSelect');
    if (headerSelect) {
        headerSelect.addEventListener('change', (e) => {
            if (e.target.value) {
                loadPreset(e.target.value);
                e.target.value = "";
            }
        });
    }

    // 5. EXPORT
    const btnExport = document.getElementById('exportPresetsBtn');
    if (btnExport) btnExport.addEventListener('click', exportPresets);

    // 6. IMPORT
    const fileInput = document.getElementById('importFile');
    if (fileInput) fileInput.addEventListener('change', importPresets);

    // Инициализация
    updateHeaderPresets();
}

// === ЛОГИКА ===

function getPresets() {
    const saved = localStorage.getItem(PRESETS_KEY);
    return saved ? JSON.parse(saved) : {};
}

function openPresetsModal() {
    const modal = document.getElementById('presetsModal');
    if(!modal) return;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    
    const search = document.getElementById('presetSearch');
    if(search) search.value = '';

    // Генерация имени
    const ticker = document.getElementById('tickerSymbol').value.trim().toUpperCase() || 'ASSET';
    const durEl = document.getElementById('duration');
    const durationText = durEl ? durEl.options[durEl.selectedIndex].text : 'Period';
    
    const now = new Date();
    const year = now.getFullYear().toString().slice(-2);
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    const nameInput = document.getElementById('newPresetName');
    if(nameInput) nameInput.value = `${ticker} - ${durationText} - ${year}-${month}-${day} - ${hours}:${minutes}`;
    
    renderPresetsList();
}

function closePresetsModal() {
    const modal = document.getElementById('presetsModal');
    if(modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

function updateHeaderPresets() {
    const selector = document.getElementById('headerPresetSelect');
    if (!selector) return;
    
    const presets = getPresets();
    selector.innerHTML = '<option value="" disabled selected>📂 Load Preset...</option>';
    
    Object.keys(presets).forEach(name => {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        selector.appendChild(option);
    });
}

function savePreset() {
    const nameInput = document.getElementById('newPresetName');
    const name = nameInput.value.trim();
    if (!name) return alert('Enter a name!');

    const currentData = {};
    PERSISTENT_IDS.forEach(id => {
        const el = document.getElementById(id);
        if (el) currentData[id] = el.type === 'checkbox' ? el.checked : el.value;
    });

    const presets = getPresets();
    presets[name] = currentData;
    localStorage.setItem(PRESETS_KEY, JSON.stringify(presets));
    
    renderPresetsList();
    updateHeaderPresets();
}

function loadPreset(name) {
    const presets = getPresets();
    const data = presets[name];
    if (!data) return;

    // 1. Заполняем все поля
    Object.keys(data).forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            if (el.type === 'checkbox') el.checked = data[id];
            else el.value = data[id];
            
            // Сохраняем в память
            localStorage.setItem(id, data[id]);
        }
    });

    // 2. ИСПРАВЛЕНИЕ: Принудительно обновляем Тикер в шапке
    const tickerInput = document.getElementById('tickerSymbol');
    if (data.tickerSymbol && tickerInput) {
        tickerInput.value = data.tickerSymbol;
        // Это важно: сообщаем системе, что тикер изменился (чтобы другие модули увидели)
        tickerInput.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // 3. UI Updates (волатильность)
    const range = document.getElementById('volatilityRange');
    if(range) document.getElementById('volatilityValueText').innerText = range.value + '%';
    
    const volCheck = document.getElementById('enableVolatility');
    const volContainer = document.getElementById('volatilityContainer');
    if(volCheck && volContainer) {
        if(volCheck.checked) volContainer.classList.remove('hidden');
        else volContainer.classList.add('hidden');
    }

    // 4. Закрываем модалку
    closePresetsModal();

    // 5. Триггер расчета (чтобы цифры обновились сразу)
    const triggerEl = document.getElementById('shares');
    if(triggerEl) triggerEl.dispatchEvent(new Event('input', { bubbles: true }));
    
    const avgShares = document.getElementById('avg_shares');
    if(avgShares) avgShares.dispatchEvent(new Event('input', { bubbles: true }));
}

// Helpers for dynamic list buttons
window.loadPresetInternal = (name) => loadPreset(name);
window.deletePresetInternal = (name) => {
    if(!confirm(`Delete "${name}"?`)) return;
    const presets = getPresets();
    delete presets[name];
    localStorage.setItem(PRESETS_KEY, JSON.stringify(presets));
    renderPresetsList();
    updateHeaderPresets();
};

function renderPresetsList() {
    const list = document.getElementById('presetsList');
    if(!list) return;

    const searchInput = document.getElementById('presetSearch');
    const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
    
    const presets = getPresets();
    const names = Object.keys(presets).filter(name => name.toLowerCase().includes(searchTerm));

    if (names.length === 0) {
        list.innerHTML = '<p class="text-sm text-gray-400 italic text-center py-2">No saved presets</p>';
        return;
    }

    list.innerHTML = '';
    names.forEach(name => {
        const div = document.createElement('div');
        div.className = 'flex justify-between items-center bg-gray-50 dark:bg-gray-800 p-2 rounded-lg border dark:border-gray-700';
        div.innerHTML = `
            <span class="font-medium text-sm truncate flex-grow">${name}</span>
            <div class="flex gap-2">
                <button onclick="window.loadPresetInternal('${name}')" class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded hover:bg-green-200 dark:bg-green-900 dark:text-green-300 font-bold">Load</button>
                <button onclick="window.deletePresetInternal('${name}')" class="text-gray-400 hover:text-red-500 px-1 font-bold">✕</button>
            </div>`;
        list.appendChild(div);
    });
}

function exportPresets() {
    const presets = getPresets();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(presets));
    
    const now = new Date();
    const filename = `PP-${now.toISOString().slice(0,10).replace(/-/g,'')}-${now.getHours()}${now.getMinutes()}.json`;
    
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", filename);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

function importPresets(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(event) {
        try {
            const imported = JSON.parse(event.target.result);
            const current = getPresets();
            const merged = { ...current, ...imported };
            localStorage.setItem(PRESETS_KEY, JSON.stringify(merged));
            
            renderPresetsList();
            updateHeaderPresets();
            alert('Presets imported successfully!');
        } catch (err) {
            console.error(err);
            alert('Error reading file. JSON invalid.');
        }
    };
    reader.readAsText(file);
    e.target.value = '';
}