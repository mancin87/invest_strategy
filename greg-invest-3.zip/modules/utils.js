export function fmtMoney(num) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(num);
}

export function initTheme() {
    const btn = document.getElementById('themeToggle');
    const html = document.documentElement;
    
    // Load saved
    if (localStorage.getItem('theme') === 'light') html.classList.remove('dark');
    
    btn.addEventListener('click', () => {
        html.classList.toggle('dark');
        localStorage.setItem('theme', html.classList.contains('dark') ? 'dark' : 'light');
    });
}