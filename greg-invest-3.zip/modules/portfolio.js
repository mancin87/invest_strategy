import { fmtMoney } from './utils.js';

const STORAGE_KEY = 'portfolio_data';
const MAPPING_KEY = 'portfolio_mapping';
const SETTINGS_KEY = 'portfolio_settings'; 

const COLUMNS = {
    group:    { label: 'GROUP',         visible: true,  align: 'center' },
    ticker:   { label: 'TICKER',        visible: true,  align: 'center' },
    avg:      { label: 'AVG. PRICE',    visible: true,  align: 'center' },
    curr:     { label: 'PRICE',         visible: true,  align: 'center' },
    qty:      { label: 'SHARES',        visible: true,  align: 'center' },
    yield:    { label: 'YIELD',         visible: true,  align: 'center' },
    value:    { label: 'VALUE',         visible: true,  align: 'center' },
    exposure: { label: 'EXPOSURE',      visible: true,  align: 'center' }, 
    pnl:      { label: 'PNL',           visible: true,  align: 'center' },
    pnlP:     { label: 'PNL %',         visible: true,  align: 'center' }
};

let portfolioAssets = [];
let chartAssetInstance = null;
let chartGroupInstance = null;
let currentSort = { col: 'value', dir: -1 }; 
let tempRawData = ""; 

export function init(registerFn) {
    if (registerFn) registerFn(refreshPortfolio);

    // 1. Google Sheet Listeners
    const btnSheet = document.getElementById('importSheetBtn');
    const btnRefresh = document.getElementById('refreshSheetBtn');
    
    // Fetch (Show mapping)
    if(btnSheet) btnSheet.addEventListener('click', () => fetchCSV('web', null, false));
    
    // Refresh (Auto-apply mapping if exists)
    if(btnRefresh) btnRefresh.addEventListener('click', () => fetchCSV('web', null, true));
    
    // 2. Local CSV Listener
    const csvInput = document.getElementById('csvFileInput');
    if(csvInput) {
        csvInput.addEventListener('change', (e) => {
            if(e.target.files[0]) {
                const file = e.target.files[0];
                document.getElementById('csvFileName').innerText = file.name;
                
                // Загружаем
                fetchCSV('local', file, false);
                
                // МГНОВЕННЫЙ сброс инпута, чтобы можно было выбрать тот же файл снова
                setTimeout(() => {
                    e.target.value = ''; 
                    document.getElementById('csvFileName').innerText = "Choose File..."; 
                }, 500);
            }
        });
    }

    // Modal Buttons
    const btnApply = document.getElementById('applyMappingBtn');
    const btnCancel = document.getElementById('cancelMappingBtn');
    if(btnApply) btnApply.addEventListener('click', applyMapping);
    if(btnCancel) btnCancel.addEventListener('click', () => {
        document.getElementById('mappingModal').classList.add('hidden');
        document.getElementById('mappingModal').classList.remove('flex');
    });

    // Control Buttons
    const btnRemap = document.getElementById('btnRemap');
    if(btnRemap) btnRemap.addEventListener('click', openRemap);

    const btnClear = document.getElementById('btnClearPortfolio');
    if(btnClear) btnClear.addEventListener('click', clearPortfolio);
    
    const btnSave = document.getElementById('btnSavePortfolio');
    if(btnSave) btnSave.addEventListener('click', exportToJSON);
    
    const jsonInput = document.getElementById('jsonFileInput');
    if(jsonInput) jsonInput.addEventListener('change', importFromJSON);

    // Columns Menu
    const btnCols = document.getElementById('toggleColsBtn');
    const colMenu = document.getElementById('columnMenu');
    if(btnCols && colMenu) {
        btnCols.addEventListener('click', (e) => {
            e.stopPropagation();
            colMenu.classList.toggle('show');
        });
        document.addEventListener('click', () => colMenu.classList.remove('show'));
        colMenu.addEventListener('click', e => e.stopPropagation());
    }

    // Load Data
    loadSettings();
    const savedData = localStorage.getItem(STORAGE_KEY);
    const savedUrl = localStorage.getItem('sheetUrl');
    
    if (savedUrl) {
        const urlInput = document.getElementById('sheetUrl');
        if(urlInput) urlInput.value = savedUrl;
    }
    
    if (savedData) {
        portfolioAssets = JSON.parse(savedData);
        recalcExposure();
        renderAll();
    }
}

// --- LOGIC ---

function cleanNum(val) {
    if (!val) return 0;
    const clean = val.replace(/[^0-9.-]/g, '');
    return parseFloat(clean) || 0;
}

function fmtQty(num) {
    if (num === 0) return "0";
    if (Math.abs(num) < 1) return num.toFixed(8).replace(/\.?0+$/, ""); 
    return num.toFixed(2);
}

function recalcExposure() {
    const total = portfolioAssets.reduce((a, b) => a + b.value, 0);
    portfolioAssets.forEach(a => {
        a.exposure = total > 0 ? (a.value / total) * 100 : 0;
    });
}

function openRemap() {
    if(!tempRawData) return alert('No raw CSV data in memory. Please Import file again.');
    const headers = tempRawData.split('\n')[0].split(',').map(h => h.trim().toUpperCase().replace(/['"]+/g, ''));
    showMapping(headers);
}

function clearPortfolio() {
    // Без confirm, как просил
    portfolioAssets = [];
    localStorage.removeItem(STORAGE_KEY);
    tempRawData = "";
    renderAll();
}

// --- FETCHING ---

async function fetchCSV(source, file = null, autoApply = false) {
    let text = "";
    const btnRefresh = document.getElementById('refreshSheetBtn');
    const btnImport = document.getElementById('importSheetBtn');
    
    // UI Loading State
    if(source === 'web') {
        if(autoApply && btnRefresh) btnRefresh.classList.add('animate-spin'); // Крутим иконку
        if(!autoApply && btnImport) btnImport.innerText = 'Loading...';
    }

    try {
        if (source === 'web') {
            const url = document.getElementById('sheetUrl').value.trim();
            if(!url) throw new Error('Enter Google Sheet URL');
            
            localStorage.setItem('sheetUrl', url);
            
            // Cache Buster
            const timestamp = new Date().getTime();
            const separator = url.includes('?') ? '&' : '?';
            const urlWithCacheBust = `${url}${separator}_t=${timestamp}`;

            const proxies = ['https://corsproxy.io/?', 'https://api.allorigins.win/raw?url='];
            
            let success = false;
            for(const p of proxies) {
                try {
                    const res = await fetch(p + encodeURIComponent(urlWithCacheBust), { cache: "no-store" });
                    if(res.ok) { 
                        text = await res.text(); 
                        success = true;
                        break; 
                    }
                } catch(e) {}
            }
            if(!success) throw new Error('Failed to fetch from Web.');

        } else if (source === 'local') {
            if(!file) return;
            text = await file.text();
        }

        if(text) {
            tempRawData = text; // Сохраняем сырые данные
            const headers = text.split('\n')[0].split(',').map(h => h.trim().toUpperCase().replace(/['"]+/g, ''));
            const savedMap = JSON.parse(localStorage.getItem(MAPPING_KEY));

            // ЛОГИКА АВТО-ОБНОВЛЕНИЯ
            if (autoApply && savedMap && Object.keys(savedMap).length > 0) {
                // Если нажали Refresh и есть сохраненный маппинг -> сразу обновляем
                processData(text, savedMap);
                
                // Визуальный сигнал успеха
                const originalColor = btnRefresh.style.color;
                btnRefresh.style.color = '#10b981'; // Green
                setTimeout(() => btnRefresh.style.color = originalColor, 1000);
            } else {
                // Иначе показываем окно маппинга
                showMapping(headers);
            }
        }

    } catch (err) {
        alert(err.message);
    } finally {
        // Reset UI
        if(btnRefresh) btnRefresh.classList.remove('animate-spin');
        if(btnImport) btnImport.innerText = 'Fetch';
    }
}

function showMapping(headers) {
    const modal = document.getElementById('mappingModal');
    const container = document.getElementById('mappingInputs');
    container.innerHTML = '';
    
    const savedMap = JSON.parse(localStorage.getItem(MAPPING_KEY));

    const fields = [
        { id: 'group',  label: 'Group' },
        { id: 'ticker', label: 'Ticker' },
        { id: 'qty',    label: 'Shares' },
        { id: 'avg',    label: 'Avg Price' },
        { id: 'curr',   label: 'Current Price' },
        { id: 'yield',  label: 'Yield %' }
    ];

    fields.forEach(f => {
        let options = headers.map((h, idx) => {
            let sel = '';
            if (savedMap && savedMap[f.id] == idx) {
                sel = 'selected';
            } else if (!savedMap) {
                if(h === f.label.toUpperCase()) sel = 'selected';
                if(f.id === 'qty' && (h.includes('SHARES') || h.includes('QTY'))) sel = 'selected';
                if(f.id === 'curr' && (h.includes('PRICE') || h.includes('MARKET') || h.includes('CURRENT'))) sel = 'selected';
                if(f.id === 'avg' && (h.includes('AVG') || h.includes('COST'))) sel = 'selected';
                if(f.id === 'yield' && (h.includes('YIELD') || h.includes('DIV'))) sel = 'selected';
            }
            return `<option value="${idx}" ${sel}>${h}</option>`;
        }).join('');
        
        container.innerHTML += `
            <div class="grid grid-cols-3 gap-4 items-center p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-100 dark:border-gray-700">
                <label class="font-bold text-sm text-gray-700 dark:text-gray-300 col-span-1">${f.label}</label>
                <div class="col-span-2 relative">
                    <select id="map_${f.id}" class="w-full appearance-none bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 py-2 px-3 pr-8 rounded leading-tight focus:outline-none focus:border-blue-500 text-sm">
                        ${options}
                    </select>
                </div>
            </div>`;
    });
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function applyMapping() {
    const map = {
        group:  document.getElementById('map_group').value,
        ticker: document.getElementById('map_ticker').value,
        qty:    document.getElementById('map_qty').value,
        avg:    document.getElementById('map_avg').value,
        curr:   document.getElementById('map_curr').value,
        yield:  document.getElementById('map_yield').value
    };
    
    localStorage.setItem(MAPPING_KEY, JSON.stringify(map));
    processData(tempRawData, map);
    document.getElementById('mappingModal').classList.add('hidden');
    document.getElementById('mappingModal').classList.remove('flex');
}

function processData(csv, map) {
    const rows = csv.split(/\r?\n/).slice(1);
    const assets = []; // Новый пустой массив

    rows.forEach(r => {
        const c = r.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/).map(s => s.trim().replace(/['"$]/g, ''));
        if(c.length < 2) return;

        const tickerRaw = c[map.ticker] || "";
        if(!tickerRaw || tickerRaw.toUpperCase().includes('TOTAL') || tickerRaw.toUpperCase().includes('SUM')) return;

        const qty = cleanNum(c[map.qty]);
        const curr = cleanNum(c[map.curr]);
        const avg = cleanNum(c[map.avg]);
        const yieldPct = cleanNum(c[map.yield]);

        if(qty === 0) return;

        assets.push({
            group: c[map.group] || 'Other',
            ticker: tickerRaw,
            qty: qty,
            avg: avg,
            curr: curr,
            yield: yieldPct,
            value: qty * curr,
            pnl: (curr - avg) * qty,
            pnlP: avg > 0 ? ((curr - avg) / avg) * 100 : 0,
            income: (qty * curr) * (yieldPct / 100),
            exposure: 0 
        });
    });

    // ЖЕСТКАЯ ПЕРЕЗАПИСЬ
    portfolioAssets = assets;
    
    recalcExposure(); 
    saveData();
    renderAll();
}

function renderAll() {
    renderMenu();
    sortData();
    renderTable();
    renderStats();
    renderCharts();
}

function renderMenu() {
    const menu = document.getElementById('columnMenu');
    if(!menu) return;
    menu.innerHTML = Object.keys(COLUMNS).map(key => `
        <label class="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer select-none transition">
            <input type="checkbox" data-col="${key}" ${COLUMNS[key].visible ? 'checked' : ''} class="rounded text-blue-600 focus:ring-blue-500">
            <span class="text-xs font-bold uppercase text-gray-600 dark:text-gray-300">${COLUMNS[key].label}</span>
        </label>
    `).join('');
    menu.querySelectorAll('input').forEach(chk => {
        chk.addEventListener('change', (e) => {
            COLUMNS[e.target.dataset.col].visible = e.target.checked;
            saveSettings();
            renderTable(); 
        });
    });
}

function sortData() {
    const { col, dir } = currentSort;
    portfolioAssets.sort((a, b) => {
        let valA = a[col];
        let valB = b[col];
        if (typeof valA === 'string') { valA = valA.toLowerCase(); valB = valB.toLowerCase(); }
        if (valA < valB) return -1 * dir;
        if (valA > valB) return 1 * dir;
        return 0;
    });
}

function handleSort(col) {
    if (currentSort.col === col) currentSort.dir *= -1; 
    else currentSort = { col: col, dir: -1 };
    sortData();
    renderTable();
}

function renderTable() {
    const thead = document.getElementById('tableHeaderRow');
    const tbody = document.getElementById('portfolioTableBody');

    thead.innerHTML = Object.keys(COLUMNS).map(key => {
        if(!COLUMNS[key].visible) return '';
        const isSorted = currentSort.col === key;
        const arrow = isSorted ? (currentSort.dir === 1 ? '↑' : '↓') : '';
        return `<th class="px-4 py-3 sort-header text-center cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 transition select-none" onclick="window.portSort('${key}')">${COLUMNS[key].label} ${arrow}</th>`;
    }).join('');

    if(portfolioAssets.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${Object.keys(COLUMNS).length}" class="text-center py-6 text-gray-400">No data loaded</td></tr>`;
        return;
    }

    tbody.innerHTML = portfolioAssets.map(asset => {
        return `<tr class="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition">
            ${COLUMNS.group.visible ? `<td class="p-2 font-medium">${asset.group}</td>` : ''}
            ${COLUMNS.ticker.visible ? `<td class="p-2 font-bold text-blue-600 dark:text-blue-400">${asset.ticker}</td>` : ''}
            ${COLUMNS.avg.visible ? `<td class="p-2 text-gray-500 text-xs font-mono">${fmtMoney(asset.avg)}</td>` : ''}
            ${COLUMNS.curr.visible ? `<td class="p-2 font-mono">${fmtMoney(asset.curr)}</td>` : ''}
            ${COLUMNS.qty.visible ? `<td class="p-2 font-mono">${fmtQty(asset.qty)}</td>` : ''}
            ${COLUMNS.yield.visible ? `<td class="p-2 text-xs font-mono">${asset.yield.toFixed(2)}%</td>` : ''}
            ${COLUMNS.value.visible ? `<td class="p-2 font-bold font-mono">${fmtMoney(asset.value)}</td>` : ''}
            ${COLUMNS.exposure.visible ? `<td class="p-2 text-xs font-bold font-mono text-gray-600 dark:text-gray-400">${asset.exposure.toFixed(2)}%</td>` : ''}
            ${COLUMNS.pnl.visible ? `<td class="p-2 font-bold font-mono ${asset.pnl >= 0 ? 'text-green-500' : 'text-red-500'}">${fmtMoney(asset.pnl)}</td>` : ''}
            ${COLUMNS.pnlP.visible ? `<td class="p-2 text-xs font-mono font-bold ${asset.pnlP >= 0 ? 'text-green-500' : 'text-red-500'}">${asset.pnlP.toFixed(2)}%</td>` : ''}
        </tr>`;
    }).join('');

    window.portSort = handleSort;
}

function renderStats() {
    const totalVal = portfolioAssets.reduce((a, b) => a + b.value, 0);
    const totalCost = portfolioAssets.reduce((a, b) => a + (b.qty * b.avg), 0);
    const totalIncome = portfolioAssets.reduce((a, b) => a + b.income, 0);
    
    const totalPnL = totalVal - totalCost;
    const totalPnLP = totalCost > 0 ? (totalPnL / totalCost) * 100 : 0;
    const avgYield = totalVal > 0 ? (totalIncome / totalVal) * 100 : 0;

    document.getElementById('statTotalValue').innerText = fmtMoney(totalVal);
    
    const pnlEl = document.getElementById('statTotalPnL');
    pnlEl.innerText = fmtMoney(totalPnL);
    pnlEl.className = `text-xl font-bold ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`;
    
    const pnlPEl = document.getElementById('statTotalPnLPercent');
    pnlPEl.innerText = `(${totalPnLP >= 0 ? '+' : ''}${totalPnLP.toFixed(2)}%)`;
    pnlPEl.className = `text-sm font-bold mb-1 ${totalPnLP >= 0 ? 'text-green-500' : 'text-red-500'}`;

    const irrEl = document.getElementById('statIRR');
    if(irrEl) {
        irrEl.innerText = `${totalPnLP >= 0 ? '+' : ''}${totalPnLP.toFixed(2)}%`;
        irrEl.className = `text-xl font-bold ${totalPnLP >= 0 ? 'text-purple-600 dark:text-purple-400' : 'text-red-500'}`;
    }

    document.getElementById('statIncome').innerText = fmtMoney(totalIncome);
    document.getElementById('statYield').innerText = `${avgYield.toFixed(2)}% Yield`;
}

function renderCharts() {
    const ctxAsset = document.getElementById('chartAssetAlloc');
    const ctxGroup = document.getElementById('chartGroupAlloc');
    if(!ctxAsset || !ctxGroup) return;

    if(chartAssetInstance) chartAssetInstance.destroy();
    if(chartGroupInstance) chartGroupInstance.destroy();

    const assetDataMap = {};
    portfolioAssets.forEach(a => assetDataMap[a.ticker] = (assetDataMap[a.ticker] || 0) + a.value);
    
    // LIMIT 30
    const assetChartData = prepareChartData(assetDataMap, 30);

    const groupDataMap = {};
    portfolioAssets.forEach(a => groupDataMap[a.group] = (groupDataMap[a.group] || 0) + a.value);
    const groupChartData = prepareChartData(groupDataMap, 30);

    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        elements: { arc: { borderColor: '#000000', borderWidth: 1 } },
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: (ctx) => {
                        const val = ctx.parsed;
                        const total = ctx.dataset.data.reduce((a,b)=>a+b,0);
                        const pct = ((val/total)*100).toFixed(1);
                        return ` ${ctx.label}: ${fmtMoney(val)} (${pct}%)`;
                    }
                }
            }
        }
    };

    chartAssetInstance = new Chart(ctxAsset, { type: 'doughnut', data: assetChartData, options: commonOptions });
    chartGroupInstance = new Chart(ctxGroup, { type: 'pie', data: groupChartData, options: commonOptions });
}

function prepareChartData(dataMap, limit) {
    const sortedKeys = Object.keys(dataMap).sort((a,b) => dataMap[b] - dataMap[a]);
    let labels = [];
    let data = [];
    let otherSum = 0;

    sortedKeys.forEach((k, i) => {
        if(i < limit) {
            labels.push(k);
            data.push(dataMap[k]);
        } else {
            otherSum += dataMap[k];
        }
    });
    
    if(otherSum > 0) {
        labels.push('Other');
        data.push(otherSum);
    }

    const palette = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#6366f1', '#14b8a6', '#f97316', '#06b6d4'];
    const colors = labels.map((_, i) => palette[i % palette.length]);

    return {
        labels: labels,
        datasets: [{ data: data, backgroundColor: colors }]
    };
}

function exportToJSON() {
    if(portfolioAssets.length === 0) return alert('No portfolio data to save.');
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(portfolioAssets));
    const now = new Date();
    const filename = `Portfolio-${now.toISOString().slice(0,10)}.json`;
    const node = document.createElement('a');
    node.setAttribute("href", dataStr);
    node.setAttribute("download", filename);
    document.body.appendChild(node);
    node.click();
    node.remove();
}

function importFromJSON(e) {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = function(event) {
        try {
            const json = JSON.parse(event.target.result);
            if(Array.isArray(json)) {
                portfolioAssets = json;
                saveData();
                renderAll();
                alert('Portfolio loaded!');
            }
        } catch(err) {}
    };
    reader.readAsText(file);
    e.target.value = '';
}

function saveData() { localStorage.setItem(STORAGE_KEY, JSON.stringify(portfolioAssets)); }
function saveSettings() { localStorage.setItem(SETTINGS_KEY, JSON.stringify(COLUMNS)); }
function loadSettings() {
    const s = localStorage.getItem(SETTINGS_KEY);
    if(s) {
        const saved = JSON.parse(s);
        Object.keys(COLUMNS).forEach(k => { if(saved[k]) COLUMNS[k].visible = saved[k].visible; });
    }
}
export function refreshPortfolio() { renderAll(); }