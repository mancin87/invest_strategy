import { fmtMoney } from './utils.js';

const AVG_INPUTS = [
    'avg_shares', 
    'avg_entryPrice', 
    'avg_marketPrice', 
    'avg_sellCount', 
    'avg_buyCount', 
    'avg_buyPrice'
];

export function init(registerFn) {
    if (registerFn) registerFn(calculate);

    loadInputs();

    AVG_INPUTS.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', (e) => {
                localStorage.setItem(id, e.target.value); 
                calculate();
            });
        }
    });

    const importBtn = document.getElementById('avgImportBtn');
    if (importBtn) importBtn.addEventListener('click', importFromProjection);

    const clearBtn = document.getElementById('avgClearBtn');
    if (clearBtn) clearBtn.addEventListener('click', clearFields);

    // --- ЗАГРУЗКА ИЗ ПОРТФЕЛЯ ---
    loadPortfolioTickers();
    const portSelect = document.getElementById('avgPortSelect');
    if (portSelect) {
        portSelect.addEventListener('focus', loadPortfolioTickers);
        portSelect.addEventListener('change', (e) => {
            if (e.target.value) loadFromPortfolio(e.target.value);
        });
    }
    // ----------------------------

    calculate();
}

function loadInputs() {
    AVG_INPUTS.forEach(id => {
        const saved = localStorage.getItem(id);
        if (saved !== null) {
            const el = document.getElementById(id);
            if(el) el.value = saved;
        }
    });
}

function loadPortfolioTickers() {
    const select = document.getElementById('avgPortSelect');
    if (!select) return;
    
    const savedPort = localStorage.getItem('portfolio_data');
    if (!savedPort || JSON.parse(savedPort).length === 0) {
        select.innerHTML = '<option value="">(Portfolio empty)</option>';
        select.disabled = true;
        return;
    }
    
    const assets = JSON.parse(savedPort);
    assets.sort((a,b) => a.ticker.localeCompare(b.ticker));
    
    const currentVal = select.value;
    select.disabled = false;
    select.innerHTML = '<option value="">Select from Portfolio...</option>' + 
        assets.map(a => `<option value="${a.ticker}">${a.ticker}</option>`).join('');
        
    if(currentVal) select.value = currentVal;
}

function loadFromPortfolio(ticker) {
    const savedPort = localStorage.getItem('portfolio_data');
    if (!savedPort) return;
    const assets = JSON.parse(savedPort);
    const asset = assets.find(a => a.ticker === ticker);
    
    if (asset) {
        // Обновляем тикер в шапке
        const tickerEl = document.getElementById('tickerSymbol');
        if(tickerEl) {
            tickerEl.value = asset.ticker;
            localStorage.setItem('tickerSymbol', asset.ticker);
        }

        document.getElementById('avg_shares').value = asset.qty;
        document.getElementById('avg_entryPrice').value = asset.avg;
        document.getElementById('avg_marketPrice').value = asset.curr;
        document.getElementById('avg_buyPrice').value = asset.curr; 
        
        // Сохраняем и пересчитываем
        const event = new Event('input');
        AVG_INPUTS.forEach(id => {
            const el = document.getElementById(id);
            if(el) {
                localStorage.setItem(id, el.value);
                el.dispatchEvent(event);
            }
        });
        
        document.getElementById('avgPortSelect').value = "";
    }
}

function importFromProjection() {
    const projShares = localStorage.getItem('shares');
    const projAvg = localStorage.getItem('avgPrice');
    const projCurr = localStorage.getItem('currPrice');

    if (!projShares && !projAvg && !projCurr) {
        alert('No data found in Projection module.');
        return;
    }

    if (projShares) document.getElementById('avg_shares').value = projShares;
    if (projAvg) document.getElementById('avg_entryPrice').value = projAvg;
    
    if (projCurr) {
        document.getElementById('avg_marketPrice').value = projCurr;
        document.getElementById('avg_buyPrice').value = projCurr;
    }

    AVG_INPUTS.forEach(id => {
        const el = document.getElementById(id);
        if(el) localStorage.setItem(id, el.value);
    });

    calculate();
}

function clearFields() {
    AVG_INPUTS.forEach(id => {
        const el = document.getElementById(id);
        if(el) {
            el.value = '';
            localStorage.removeItem(id);
        }
    });
    
    const portSelect = document.getElementById('avgPortSelect');
    if(portSelect) portSelect.value = "";

    calculate();
}

export function calculate() {
    const shares = parseFloat(document.getElementById('avg_shares').value) || 0;
    const avgPrice = parseFloat(document.getElementById('avg_entryPrice').value) || 0;
    const mktPrice = parseFloat(document.getElementById('avg_marketPrice').value) || 0;
    
    const sellQty = parseFloat(document.getElementById('avg_sellCount').value) || 0;
    const buyQty = parseFloat(document.getElementById('avg_buyCount').value) || 0;
    const buyPrice = parseFloat(document.getElementById('avg_buyPrice').value) || 0;

    const oldInvested = shares * avgPrice;
    const currentVal = shares * mktPrice;
    const oldPnL = currentVal - oldInvested;

    // 1. Продажа
    const realizedPnL = sellQty * (mktPrice - avgPrice);
    const cashReleased = sellQty * mktPrice;

    let remainingShares = shares - sellQty;
    if (remainingShares < 0) remainingShares = 0; 
    let remainingInvested = remainingShares * avgPrice; 

    // 2. Покупка
    let finalShares = remainingShares + buyQty;
    let finalInvested = remainingInvested + (buyQty * buyPrice);

    let newAvg = finalShares > 0 ? finalInvested / finalShares : 0;
    
    const newMktVal = finalShares * mktPrice; 
    const remainingPnL = newMktVal - finalInvested;
    
    let improvement = 0;
    if (avgPrice > 0 && newAvg > 0) {
        improvement = ((avgPrice - newAvg) / avgPrice) * 100;
    }

    setText('res_oldAvg', fmtMoney(avgPrice));
    setText('res_oldInvested', fmtMoney(oldInvested));
    setPnL('res_oldPnL', oldPnL);

    setText('res_newAvg', fmtMoney(newAvg));
    setText('res_newShares', finalShares.toFixed(2));
    setText('res_newInvested', fmtMoney(finalInvested));
    setPnL('res_remainingPnL', remainingPnL);

    setPnL('res_realizedPnL', realizedPnL);
    setText('res_cashReleased', fmtMoney(cashReleased));
    
    const impEl = document.getElementById('res_improvement');
    if(impEl) {
        impEl.innerText = improvement.toFixed(2) + '%';
        impEl.className = `text-xl font-bold ${improvement > 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-500'}`;
    }
}

function setText(id, val) {
    const el = document.getElementById(id);
    if(el) el.innerText = val;
}

function setPnL(id, val) {
    const el = document.getElementById(id);
    if(el) {
        el.innerText = fmtMoney(val);
        el.className = val >= 0 
            ? 'font-mono font-bold text-green-500' 
            : 'font-mono font-bold text-red-500';
    }
}