import { fmtMoney } from './utils.js';

export function init(registerFn) {
    const input = document.getElementById('tickerSymbol');
    const resultsBox = document.getElementById('searchResults');

    if (!input || !resultsBox) return;

    let timeout;

    // Функция запуска поиска с задержкой
    const triggerSearch = (query) => {
        clearTimeout(timeout);
        if (query.length < 1) {
            resultsBox.classList.add('hidden');
            return;
        }
        // Уменьшили задержку до 300мс для отзывчивости
        timeout = setTimeout(() => {
            fetchTickerSuggestions(query);
        }, 300);
    };

    // 1. Слушаем ввод (INPUT)
    input.addEventListener('input', (e) => {
        // ГЛАВНОЕ ИСПРАВЛЕНИЕ:
        // isTrusted = true, если событие вызвано действием пользователя (клавиатура).
        // isTrusted = false, если событие вызвано скриптом (загрузка пресета).
        if (!e.isTrusted) return; 

        const query = e.target.value.trim();
        triggerSearch(query);
    });

    // 2. Слушаем фокус (FOCUS) - клик мышкой по полю
    input.addEventListener('focus', (e) => {
        const query = e.target.value.trim();
        // Если там уже что-то написано, запускаем поиск снова, чтобы показать варианты
        if (query.length > 0) {
            triggerSearch(query);
        }
    });

    // 3. Скрытие при клике вне
    document.addEventListener('click', (e) => {
        if (!input.contains(e.target) && !resultsBox.contains(e.target)) {
            resultsBox.classList.add('hidden');
        }
    });
}

// Поиск списка (Proxy)
async function fetchTickerSuggestions(query) {
    const resultsBox = document.getElementById('searchResults');
    resultsBox.classList.remove('hidden');
    resultsBox.innerHTML = '<div class="p-3 text-xs text-gray-500">Searching...</div>';

    const yahooUrl = `https://query1.finance.yahoo.com/v1/finance/search?q=${query}&quotesCount=6&newsCount=0`;
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(yahooUrl)}`;

    try {
        const response = await fetch(proxyUrl, { referrerPolicy: "no-referrer" });
        const wrappedData = await response.json();
        
        const data = JSON.parse(wrappedData.contents);
        
        if (data.quotes && data.quotes.length > 0) {
            renderResults(data.quotes);
        } else {
            resultsBox.innerHTML = '<div class="p-3 text-xs text-gray-500">No results found</div>';
        }
    } catch (e) {
        console.error("Search Error:", e);
        // Не пугаем пользователя красным текстом, если просто сбой сети, просто скрываем
        resultsBox.innerHTML = '<div class="p-3 text-xs text-gray-400">Connection error</div>';
    }
}

// Рендер результатов
function renderResults(quotes) {
    const resultsBox = document.getElementById('searchResults');
    resultsBox.innerHTML = '';

    quotes.forEach(item => {
        if (!item.symbol || !item.shortname) return;

        const div = document.createElement('div');
        div.className = 'p-3 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer border-b dark:border-gray-700 last:border-0 transition';
        div.innerHTML = `
            <div class="flex justify-between items-center">
                <span class="font-bold text-blue-600 dark:text-blue-400">${item.symbol}</span>
                <span class="text-xs text-gray-400 border border-gray-200 dark:border-gray-600 rounded px-1">${item.exchange || 'US'}</span>
            </div>
            <div class="text-xs text-gray-600 dark:text-gray-300 truncate">${item.shortname}</div>
        `;

        div.addEventListener('click', () => selectTicker(item.symbol));
        resultsBox.appendChild(div);
    });
}

// Выбор тикера
async function selectTicker(symbol) {
    const input = document.getElementById('tickerSymbol');
    const resultsBox = document.getElementById('searchResults');
    
    input.value = symbol;
    resultsBox.classList.add('hidden');
    
    const inputGroup = input.closest('.group'); 
    if(inputGroup) inputGroup.classList.add('opacity-50');

    try {
        const price = await fetchCurrentPrice(symbol);
        if (price) {
            updateAllPriceFields(price);
        } else {
            alert('Price data not available for ' + symbol);
        }
    } catch (e) {
        console.error(e);
        // Молчим при ошибке, чтобы не спамить алертами
    } finally {
        if(inputGroup) inputGroup.classList.remove('opacity-50');
    }
}

// Получение цены
async function fetchCurrentPrice(symbol) {
    const yahooUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1d&range=1d`;
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(yahooUrl)}`;

    const response = await fetch(proxyUrl, { referrerPolicy: "no-referrer" });
    const wrappedData = await response.json();
    const data = JSON.parse(wrappedData.contents);

    const result = data.chart?.result?.[0];
    if (!result) return null;

    return result.meta.regularMarketPrice || result.meta.chartPreviousClose || null;
}

// Обновление полей
function updateAllPriceFields(price) {
    const ticker = document.getElementById('tickerSymbol').value;
    localStorage.setItem('tickerSymbol', ticker);
    localStorage.setItem('currPrice', price);

    // Module: Projection
    const projPrice = document.getElementById('currPrice');
    if (projPrice) {
        projPrice.value = price;
        projPrice.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Module: Averaging
    const avgAssetPrice = document.getElementById('avg_marketPrice');
    const avgBuyPrice = document.getElementById('avg_buyPrice');
    
    if (avgAssetPrice) {
        avgAssetPrice.value = price;
        avgAssetPrice.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    if (avgBuyPrice) {
        avgBuyPrice.value = price;
        localStorage.setItem('avg_buyPrice', price);
    }
}